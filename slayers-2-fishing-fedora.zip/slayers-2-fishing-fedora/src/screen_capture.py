from __future__ import annotations

import time
from typing import Callable

from wayland_portal import is_wayland, portal

IS_WAYLAND = is_wayland()


class ScreenShareUnavailable(RuntimeError):
    pass


class _PortalCapture:

    def __enter__(self) -> "_PortalCapture":
        return self

    def __exit__(self, *_exc) -> None:
        pass

    @property
    def monitors(self) -> list[dict]:
        x, y, w, h = portal.stream_rect or (0, 0, 1920, 1080)
        mon = {"left": x, "top": y, "width": w, "height": h}
        return [mon, dict(mon)]

    def grab(self, mon: dict):
        return portal.grab(mon["left"], mon["top"], mon["width"], mon["height"])


def open_capture():
    if IS_WAYLAND:
        return _PortalCapture()
    import mss

    return (getattr(mss, "MSS", None) or mss.mss)()


def ensure_screen_share(should_abort: Callable[[], bool], set_status: Callable[[str], None]) -> bool:
    if not IS_WAYLAND or portal.state == "ready":
        return True
    if portal.state != "starting":
        portal.start()
    set_status("Waiting on the screen share popup, check your screen")
    while not portal.wait_ready(0.2):
        if should_abort():
            return False
    if portal.state != "ready":
        raise ScreenShareUnavailable(
            "Screen share wasnt allowed (%s). Press Start to try again" % (portal.error or "unknown")
        )
    time.sleep(0.1)
    return True
