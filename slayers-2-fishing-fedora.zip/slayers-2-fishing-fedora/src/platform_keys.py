from __future__ import annotations

import sys
import threading
import time
from typing import Callable

IS_WINDOWS = sys.platform == "win32"

from wayland_portal import is_wayland

IS_WAYLAND = is_wayland()

_SPECIAL_TO_CHAR = {
    "Space": "space",
    "Plus": "+",
    "Minus": "-",
    "Equal": "=",
    "Comma": ",",
    "Period": ".",
    "Slash": "/",
    "Backslash": "\\",
    "LeftBracket": "[",
    "RightBracket": "]",
    "Semicolon": ";",
    "Quote": "'",
    "Grave": "`",
    "PageUp": "page up",
    "PageDown": "page down",
}


def to_keyboard_name(key: str) -> str:
    if key in _SPECIAL_TO_CHAR:
        return _SPECIAL_TO_CHAR[key]
    return key.lower()


if IS_WINDOWS:
    import keyboard as _kb

    def key_press(name: str) -> None:
        _kb.press(name)

    def key_release(name: str) -> None:
        _kb.release(name)

    def add_hotkey(name: str, callback: Callable[[], None], label: str | None = None):
        return _kb.add_hotkey(to_keyboard_name(name), callback, suppress=False)

    def remove_hotkey(handle) -> None:
        _kb.remove_hotkey(handle)

    def unhook_all() -> None:
        _kb.unhook_all_hotkeys()

    def dispatch_key(name: str) -> None:
        pass

elif IS_WAYLAND:
    from wayland_portal import portal as _portal

    _lock = threading.Lock()
    _hotkeys: dict[int, tuple[str, str, Callable[[], None]]] = {}
    _last_fire: dict[str, float] = {}
    _next_id = 1
    _bind_timer: threading.Timer | None = None

    def key_press(name: str) -> None:
        _portal.key(name, True)

    def key_release(name: str) -> None:
        _portal.key(name, False)

    def _fire(name: str) -> None:
        now = time.monotonic()
        with _lock:
            if now - _last_fire.get(name, 0.0) < 0.25:
                return
            _last_fire[name] = now
            cbs = [cb for (n, _l, cb) in _hotkeys.values() if n == name]
        for cb in cbs:
            try:
                cb()
            except Exception:
                pass

    def _bind_now() -> None:
        with _lock:
            spec = {}
            for n, label, _cb in _hotkeys.values():
                sid = "".join(c if c.isalnum() else "-" for c in (label + " " + n).lower()).strip("-")
                spec[sid] = ("Slayers 2 Fishing: " + label, n, lambda n=n: _fire(n))
        if spec:
            _portal.bind_shortcuts(spec)

    def _schedule_bind() -> None:
        global _bind_timer
        with _lock:
            if _bind_timer is not None:
                _bind_timer.cancel()
            _bind_timer = threading.Timer(0.4, _bind_now)
            _bind_timer.daemon = True
            _bind_timer.start()

    def add_hotkey(name: str, callback: Callable[[], None], label: str | None = None):
        global _next_id
        with _lock:
            handle = _next_id
            _next_id += 1
            _hotkeys[handle] = (str(name), label or str(name), callback)
        _schedule_bind()
        return handle

    def remove_hotkey(handle) -> None:
        with _lock:
            _hotkeys.pop(handle, None)

    def unhook_all() -> None:
        with _lock:
            _hotkeys.clear()
            if _bind_timer is not None:
                _bind_timer.cancel()

    def dispatch_key(name: str) -> None:
        _fire(name)

else:
    from pynput import keyboard as _pk

    _ctl = _pk.Controller()
    _lock = threading.Lock()
    _hotkeys: dict[int, tuple[str, Callable[[], None]]] = {}
    _listener: _pk.Listener | None = None
    _next_id = 1

    _CHAR_TO_SPECIAL = {
        " ": "Space",
        "+": "Plus",
        "-": "Minus",
        "=": "Equal",
        ",": "Comma",
        ".": "Period",
        "/": "Slash",
        "\\": "Backslash",
        "[": "LeftBracket",
        "]": "RightBracket",
        ";": "Semicolon",
        "'": "Quote",
        "`": "Grave",
    }
    _KEY_TO_SPECIAL = {}
    for _attr, _name in (("space", "Space"), ("page_up", "PageUp"), ("page_down", "PageDown"),
                         ("up", "Up"), ("down", "Down"), ("left", "Left"), ("right", "Right"),
                         ("insert", "Insert"), ("delete", "Delete"), ("home", "Home"), ("end", "End")):
        _k = getattr(_pk.Key, _attr, None)
        if _k is not None:
            _KEY_TO_SPECIAL[_k] = _name

    def _canonical(key) -> str | None:
        if isinstance(key, _pk.KeyCode):
            ch = key.char
            if not ch:
                return None
            if ch in _CHAR_TO_SPECIAL:
                return _CHAR_TO_SPECIAL[ch]
            if len(ch) == 1:
                return ch.upper()
            return None
        if key in _KEY_TO_SPECIAL:
            return _KEY_TO_SPECIAL[key]
        name = getattr(key, "name", "") or ""
        if name.startswith("f") and name[1:].isdigit():
            return name.upper()
        return None

    def _on_press(key) -> None:
        name = _canonical(key)
        if name is None:
            return
        with _lock:
            cbs = [cb for (n, cb) in _hotkeys.values() if n == name]
        for cb in cbs:
            try:
                cb()
            except Exception:
                pass

    def _ensure_listener() -> None:
        global _listener
        if _listener is None or not _listener.is_alive():
            _listener = _pk.Listener(on_press=_on_press)
            _listener.daemon = True
            _listener.start()

    def _to_pynput(name: str):
        name = str(name)
        if len(name) == 1:
            return name.lower()
        low = name.lower()
        if low.startswith("f") and low[1:].isdigit():
            return getattr(_pk.Key, low)
        if name in _SPECIAL_TO_CHAR:
            ch = _SPECIAL_TO_CHAR[name]
            if ch == "space":
                return _pk.Key.space
            if ch == "page up":
                return _pk.Key.page_up
            if ch == "page down":
                return _pk.Key.page_down
            return ch
        return getattr(_pk.Key, low, None)

    _MAC_KEYCODES = {
        "esc": 53, "escape": 53, "enter": 36, "return": 36, "tab": 48,
        "space": 49, "backspace": 51, "delete": 51, "end": 119, "home": 115,
        "ctrl": 59, "shift": 56, "alt": 58, "cmd": 55,
        "0": 29, "1": 18, "2": 19, "3": 20, "4": 21, "5": 23,
        "6": 22, "7": 26, "8": 28, "9": 25, "a": 0, "b": 11, "c": 8, "d": 2,
        "e": 14, "f": 3, "g": 5, "h": 4, "i": 34, "j": 38, "k": 40, "l": 37,
        "m": 46, "n": 45, "o": 31, "p": 35, "q": 12, "r": 15, "s": 1, "t": 17,
        "u": 32, "v": 9, "w": 13, "x": 7, "y": 16, "z": 6,
    }
    if sys.platform == "darwin":
        try:
            from Quartz import CGEventCreateKeyboardEvent, CGEventPost, kCGHIDEventTap as _TAP
        except Exception:
            CGEventCreateKeyboardEvent = None
    else:
        CGEventCreateKeyboardEvent = None

    def _mac_key(name: str, down: bool) -> bool:
        if CGEventCreateKeyboardEvent is None:
            return False
        code = _MAC_KEYCODES.get(str(name).lower())
        if code is None:
            return False
        CGEventPost(_TAP, CGEventCreateKeyboardEvent(None, code, down))
        return True

    def key_press(name: str) -> None:
        if _mac_key(name, True):
            return
        k = _to_pynput(name)
        if k is not None:
            _ctl.press(k)

    def key_release(name: str) -> None:
        if _mac_key(name, False):
            return
        k = _to_pynput(name)
        if k is not None:
            _ctl.release(k)

    def add_hotkey(name: str, callback: Callable[[], None], label: str | None = None):
        global _next_id
        with _lock:
            handle = _next_id
            _next_id += 1
            _hotkeys[handle] = (str(name), callback)
        _ensure_listener()
        return handle

    def remove_hotkey(handle) -> None:
        with _lock:
            _hotkeys.pop(handle, None)

    def unhook_all() -> None:
        global _listener
        with _lock:
            _hotkeys.clear()
        if _listener is not None:
            try:
                _listener.stop()
            except Exception:
                pass
            _listener = None

    def dispatch_key(name: str) -> None:
        pass
