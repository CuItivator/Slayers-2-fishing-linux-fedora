from __future__ import annotations

import os
import secrets
import sys
import threading
from typing import Callable

import numpy as np

APP_ID = "io.github.vtt.Slayers2Fishing"

BUS_NAME = "org.freedesktop.portal.Desktop"
OBJ_PATH = "/org/freedesktop/portal/desktop"
RD_IFACE = "org.freedesktop.portal.RemoteDesktop"
SC_IFACE = "org.freedesktop.portal.ScreenCast"
GS_IFACE = "org.freedesktop.portal.GlobalShortcuts"
REQ_IFACE = "org.freedesktop.portal.Request"
SESSION_IFACE = "org.freedesktop.portal.Session"
REGISTRY_IFACE = "org.freedesktop.host.portal.Registry"

DEVICE_KEYBOARD = 1
DEVICE_POINTER = 2
SOURCE_MONITOR = 1
CURSOR_HIDDEN = 1
CURSOR_EMBEDDED = 2
PERSIST_UNTIL_REVOKED = 2

BTN_LEFT = 0x110

_EVDEV = {
    "esc": 1, "escape": 1, "1": 2, "2": 3, "3": 4, "4": 5, "5": 6, "6": 7, "7": 8,
    "8": 9, "9": 10, "0": 11, "-": 12, "=": 13, "backspace": 14, "tab": 15,
    "q": 16, "w": 17, "e": 18, "r": 19, "t": 20, "y": 21, "u": 22, "i": 23,
    "o": 24, "p": 25, "[": 26, "]": 27, "enter": 28, "return": 28, "ctrl": 29,
    "a": 30, "s": 31, "d": 32, "f": 33, "g": 34, "h": 35, "j": 36, "k": 37,
    "l": 38, ";": 39, "'": 40, "`": 41, "shift": 42, "\\": 43, "z": 44,
    "x": 45, "c": 46, "v": 47, "b": 48, "n": 49, "m": 50, ",": 51, ".": 52,
    "/": 53, "alt": 56, "space": 57, " ": 57,
    "f1": 59, "f2": 60, "f3": 61, "f4": 62, "f5": 63, "f6": 64, "f7": 65,
    "f8": 66, "f9": 67, "f10": 68, "f11": 87, "f12": 88,
    "home": 102, "up": 103, "page_up": 104, "pageup": 104, "left": 105,
    "right": 106, "end": 107, "down": 108, "page_down": 109, "pagedown": 109,
    "insert": 110, "delete": 111,
}

_SPECIAL_EVDEV = {
    "Space": "space", "Plus": "=", "Minus": "-", "Equal": "=", "Comma": ",",
    "Period": ".", "Slash": "/", "Backslash": "\\", "LeftBracket": "[",
    "RightBracket": "]", "Semicolon": ";", "Quote": "'", "Grave": "`",
    "PageUp": "page_up", "PageDown": "page_down",
}

_SPECIAL_TRIGGER = {
    "Space": "space", "Plus": "plus", "Minus": "minus", "Equal": "equal",
    "Comma": "comma", "Period": "period", "Slash": "slash",
    "Backslash": "backslash", "LeftBracket": "bracketleft",
    "RightBracket": "bracketright", "Semicolon": "semicolon",
    "Quote": "apostrophe", "Grave": "grave", "PageUp": "Page_Up",
    "PageDown": "Page_Down", "Up": "Up", "Down": "Down", "Left": "Left",
    "Right": "Right", "Insert": "Insert", "Delete": "Delete", "Home": "Home",
    "End": "End",
}


def is_wayland() -> bool:
    if not sys.platform.startswith("linux"):
        return False
    if os.environ.get("SLAYERS_FORCE_X11"):
        return False
    if os.environ.get("XDG_SESSION_TYPE", "").lower() == "wayland":
        return True
    return bool(os.environ.get("WAYLAND_DISPLAY"))


def evdev_code(name: str) -> int | None:
    name = str(name)
    name = _SPECIAL_EVDEV.get(name, name)
    return _EVDEV.get(name.lower())


def shortcut_trigger(name: str) -> str:
    name = str(name)
    if name in _SPECIAL_TRIGGER:
        return _SPECIAL_TRIGGER[name]
    if name.upper().startswith("F") and name[1:].isdigit():
        return name.upper()
    if len(name) == 1:
        return name.lower()
    return name


class PortalError(RuntimeError):
    pass


class _NoInput(Exception):
    pass


def _token_file() -> str:
    from app_paths import writable_dir
    return str(writable_dir() / ".portal-restore-token")


class _Portal:
    def __init__(self) -> None:
        self.state = "idle"
        self.error = ""
        self._start_lock = threading.Lock()
        self._loop_lock = threading.Lock()
        self._ready = threading.Event()
        self._thread: threading.Thread | None = None
        self._ctx = None
        self._loop = None
        self._bus = None
        self._session = ""
        self._node = 0
        self.stream_rect: tuple[int, int, int, int] | None = None
        self._pipeline = None
        self._sample = None
        self._sample_lock = threading.Lock()
        self._frame_seen = threading.Event()
        self._gs_session = ""
        self._gs_sub = None
        self._gs_callbacks: dict[str, Callable[[], None]] = {}
        self._gs_lock = threading.Lock()
        self.shortcuts_active = False
        self.status_cb: Callable[[str], None] | None = None

    def _status(self, msg: str) -> None:
        cb = self.status_cb
        if cb is not None:
            try:
                cb(msg)
            except Exception:
                pass

    def _ensure_loop(self) -> None:
        with self._loop_lock:
            if self._thread is None:
                self._start_loop()

    def _start_loop(self) -> None:
        from gi.repository import Gio, GLib

        self._bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        self._ctx = GLib.MainContext.new()
        self._loop = GLib.MainLoop.new(self._ctx, False)
        started = threading.Event()

        def run() -> None:
            self._ctx.push_thread_default()
            src = GLib.idle_source_new()
            src.set_callback(lambda *_: (started.set(), False)[1])
            src.attach(self._ctx)
            self._loop.run()

        self._thread = threading.Thread(target=run, name="portal-glib", daemon=True)
        self._thread.start()
        started.wait(5)
        self._register_app()

    def _in_loop(self, fn):
        from gi.repository import GLib

        done = threading.Event()
        box: dict = {}

        def wrapper(*_):
            try:
                box["r"] = fn()
            except Exception as exc:
                box["e"] = exc
            done.set()
            return False

        src = GLib.idle_source_new()
        src.set_callback(wrapper)
        src.attach(self._ctx)
        done.wait()
        if "e" in box:
            raise box["e"]
        return box.get("r")

    def _call(self, iface: str, method: str, sig: str, args: tuple, path: str = OBJ_PATH):
        from gi.repository import Gio, GLib

        res = self._bus.call_sync(
            BUS_NAME, path, iface, method,
            GLib.Variant(sig, args) if sig else None,
            None, Gio.DBusCallFlags.NONE, -1, None,
        )
        return res.unpack() if res is not None else None

    def _register_app(self) -> None:
        try:
            self._call(REGISTRY_IFACE, "Register", "(sa{sv})", (APP_ID, {}))
        except Exception:
            pass

    def _request(self, iface: str, method: str, sig: str, make_args, timeout: float | None = None) -> dict:
        from gi.repository import Gio, GLib

        token = "s2f" + secrets.token_hex(6)
        sender = self._bus.get_unique_name()[1:].replace(".", "_")
        path = f"/org/freedesktop/portal/desktop/request/{sender}/{token}"
        done = threading.Event()
        box: dict = {}

        def on_response(_conn, _sender, _path, _iface, _signal, params, *_ud):
            code, results = params.unpack()
            box["code"] = code
            box["results"] = results
            done.set()

        sub = self._in_loop(lambda: self._bus.signal_subscribe(
            None, REQ_IFACE, "Response", path, None, Gio.DBusSignalFlags.NONE, on_response))
        try:
            self._call(iface, method, sig, make_args(GLib.Variant("s", token)))
            if not done.wait(timeout):
                raise PortalError(f"{method}: no answer from the desktop")
        finally:
            self._in_loop(lambda: self._bus.signal_unsubscribe(sub))
        if box["code"] == 1:
            raise PortalError(f"{method}: cancelled")
        if box["code"] != 0:
            raise PortalError(f"{method}: failed")
        return box["results"]

    def start(self, wait: bool = False, timeout: float = 120.0) -> bool:
        with self._start_lock:
            if self.state in ("idle", "failed", "closed"):
                self.state = "starting"
                self.error = ""
                self._ready.clear()
                threading.Thread(target=self._start_worker, name="portal-start", daemon=True).start()
        if wait:
            self._ready.wait(timeout)
        return self.state == "ready"

    def wait_ready(self, timeout: float) -> bool:
        self._ready.wait(timeout)
        return self.state == "ready"

    def _start_worker(self) -> None:
        try:
            self._ensure_loop()
            self._open_session()
            self._start_pipeline()
            if not self._frame_seen.wait(3.0):
                raise PortalError("screen stream started but sent no picture")
            self.state = "ready"
            self._status("Ready to fish. Click into Roblox and press your start key")
        except Exception as exc:
            self.error = str(exc)
            self.state = "failed"
            self._stop_pipeline()
            if "cancel" in self.error:
                self._status("Screen share got cancelled. Press Start to get the popup again")
            else:
                self._status(f"Screen share didnt work: {self.error}")
        finally:
            self._ready.set()

    def _open_session(self) -> None:
        try:
            with open(_token_file(), encoding="utf-8") as f:
                restore = f.read().strip()
        except OSError:
            restore = ""
        try:
            self._open_session_once(restore)
        except _NoInput:
            self._forget_token()
            if not restore:
                raise PortalError(
                    "mouse and keyboard control was off. Press Start again and turn ON "
                    "Allow Remote Interaction in the popup")
            self._open_session_once("")

    def _forget_token(self) -> None:
        try:
            os.remove(_token_file())
        except OSError:
            pass
        if self._session:
            try:
                self._call(SESSION_IFACE, "Close", "", (), path=self._session)
            except Exception:
                pass
            self._session = ""

    def _open_session_once(self, restore: str) -> None:
        from gi.repository import GLib

        V = GLib.Variant
        self._status("Popup time: pick your screen, turn ON Allow Remote "
                     "Interaction, then press Share")
        res = self._request(RD_IFACE, "CreateSession", "(a{sv})", lambda t: ({
            "handle_token": t,
            "session_handle_token": V("s", "s2f" + secrets.token_hex(6)),
        },))
        self._session = str(res["session_handle"])

        def devices_args(t):
            opts = {
                "handle_token": t,
                "types": V("u", DEVICE_KEYBOARD | DEVICE_POINTER),
                "persist_mode": V("u", PERSIST_UNTIL_REVOKED),
            }
            if restore:
                opts["restore_token"] = V("s", restore)
            return (self._session, opts)

        self._request(RD_IFACE, "SelectDevices", "(oa{sv})", devices_args)

        try:
            modes = int(self._bus.call_sync(
                BUS_NAME, OBJ_PATH, "org.freedesktop.DBus.Properties", "Get",
                V("(ss)", (SC_IFACE, "AvailableCursorModes")), None, 0, -1, None,
            ).unpack()[0])
        except Exception:
            modes = CURSOR_EMBEDDED
        cursor = CURSOR_HIDDEN if modes & CURSOR_HIDDEN else CURSOR_EMBEDDED

        self._request(SC_IFACE, "SelectSources", "(oa{sv})", lambda t: (self._session, {
            "handle_token": t,
            "types": V("u", SOURCE_MONITOR),
            "multiple": V("b", False),
            "cursor_mode": V("u", cursor),
        }))

        res = self._request(RD_IFACE, "Start", "(osa{sv})", lambda t: (self._session, "", {
            "handle_token": t,
        }))
        devices = int(res.get("devices", 0))
        if devices & (DEVICE_POINTER | DEVICE_KEYBOARD) != (DEVICE_POINTER | DEVICE_KEYBOARD):
            raise _NoInput()
        token = res.get("restore_token")
        if token:
            try:
                with open(_token_file(), "w", encoding="utf-8") as f:
                    f.write(str(token))
            except OSError:
                pass
        streams = res.get("streams") or []
        if not streams:
            raise PortalError("no screen was shared")
        node, props = streams[0]
        self._node = int(node)
        pos = props.get("position") or (0, 0)
        size = props.get("size") or (0, 0)
        self.stream_rect = (int(pos[0]), int(pos[1]), int(size[0]), int(size[1]))

        def on_closed(*_):
            self.state = "closed"
            self._stop_pipeline()
            self._status("Screen share stopped. Press Start to share again")

        self._in_loop(lambda: self._bus.signal_subscribe(
            None, SESSION_IFACE, "Closed", self._session, None, 0, on_closed))

    def _open_pipewire_fd(self) -> int:
        from gi.repository import Gio, GLib

        res, fds = self._bus.call_with_unix_fd_list_sync(
            BUS_NAME, OBJ_PATH, SC_IFACE, "OpenPipeWireRemote",
            GLib.Variant("(oa{sv})", (self._session, {})),
            GLib.VariantType("(h)"), Gio.DBusCallFlags.NONE, -1, None, None,
        )
        return fds.get(res.unpack()[0])

    def _start_pipeline(self) -> None:
        import gi

        gi.require_version("Gst", "1.0")
        from gi.repository import Gst

        Gst.init(None)
        fd = self._open_pipewire_fd()
        desc = (
            f"pipewiresrc fd={fd} path={self._node} always-copy=true keepalive-time=500 "
            "! videoconvert ! video/x-raw,format=BGRx "
            "! appsink name=sink emit-signals=true max-buffers=1 drop=true sync=false"
        )
        pipeline = Gst.parse_launch(desc)
        sink = pipeline.get_by_name("sink")

        def on_sample(s):
            sample = s.emit("pull-sample")
            if sample is not None:
                with self._sample_lock:
                    self._sample = sample
                self._frame_seen.set()
            return Gst.FlowReturn.OK

        sink.connect("new-sample", on_sample)
        self._pipeline = pipeline
        if pipeline.set_state(Gst.State.PLAYING) == Gst.StateChangeReturn.FAILURE:
            raise PortalError("could not start the screen stream")

    def _stop_pipeline(self) -> None:
        p, self._pipeline = self._pipeline, None
        if p is not None:
            try:
                from gi.repository import Gst
                p.set_state(Gst.State.NULL)
            except Exception:
                pass
        with self._sample_lock:
            self._sample = None
        self._frame_seen.clear()

    def grab(self, left: int, top: int, width: int, height: int) -> np.ndarray:
        width, height = max(1, int(width)), max(1, int(height))
        with self._sample_lock:
            sample = self._sample
        if sample is None or self.stream_rect is None:
            raise PortalError("no screen picture yet (screen share not running)")
        caps = sample.get_caps().get_structure(0)
        fw, fh = int(caps.get_value("width")), int(caps.get_value("height"))
        buf = sample.get_buffer()
        stride = buf.get_size() // max(1, fh)
        sx, sy, sw, sh = self.stream_rect
        kx = fw / sw if sw > 0 else 1.0
        ky = fh / sh if sh > 0 else 1.0
        px0 = int(round((left - sx) * kx))
        py0 = int(round((top - sy) * ky))
        pw = max(1, int(round(width * kx)))
        ph = max(1, int(round(height * ky)))
        cx0, cy0 = max(0, px0), max(0, py0)
        cx1, cy1 = min(fw, px0 + pw), min(fh, py0 + ph)
        out = np.zeros((ph, pw, 4), dtype=np.uint8)
        if cx1 > cx0 and cy1 > cy0:
            raw = buf.extract_dup(cy0 * stride, (cy1 - cy0) * stride)
            rows = np.frombuffer(raw, dtype=np.uint8).reshape(cy1 - cy0, stride)
            part = rows[:, cx0 * 4:cx1 * 4].reshape(cy1 - cy0, cx1 - cx0, 4)
            out[cy0 - py0:cy1 - py0, cx0 - px0:cx1 - px0] = part
        out[:, :, 3] = 255
        if (pw, ph) != (width, height):
            import cv2
            out = cv2.resize(out, (width, height), interpolation=cv2.INTER_AREA)
        return out

    def _notify(self, method: str, sig: str, *args) -> None:
        if self.state != "ready":
            raise PortalError("mouse/keyboard control not ready (screen share not running)")
        self._call(RD_IFACE, method, sig, (self._session, {}) + tuple(args))

    def pointer_move(self, x: float, y: float) -> None:
        sx, sy, _sw, _sh = self.stream_rect
        self._notify("NotifyPointerMotionAbsolute", "(oa{sv}udd)",
                     self._node, float(x - sx), float(y - sy))

    def pointer_button(self, pressed: bool, button: int = BTN_LEFT) -> None:
        self._notify("NotifyPointerButton", "(oa{sv}iu)", int(button), 1 if pressed else 0)

    def key(self, name: str, pressed: bool) -> None:
        code = evdev_code(name)
        if code is None:
            raise PortalError(f"unknown key {name!r}")
        self._notify("NotifyKeyboardKeycode", "(oa{sv}iu)", int(code), 1 if pressed else 0)

    def bind_shortcuts(self, shortcuts: dict[str, tuple[str, str, Callable[[], None]]]) -> bool:
        from gi.repository import GLib

        V = GLib.Variant
        with self._gs_lock:
            try:
                self._ensure_loop()
                if self._gs_session:
                    try:
                        self._call(SESSION_IFACE, "Close", "", (), path=self._gs_session)
                    except Exception:
                        pass
                    self._gs_session = ""
                self.shortcuts_active = False
                res = self._request(GS_IFACE, "CreateSession", "(a{sv})", lambda t: ({
                    "handle_token": t,
                    "session_handle_token": V("s", "s2f" + secrets.token_hex(6)),
                },), timeout=30)
                self._gs_session = str(res["session_handle"])
                self._gs_callbacks = {sid: cb for sid, (_d, _k, cb) in shortcuts.items()}
                spec = [
                    (sid, {"description": V("s", desc), "preferred_trigger": V("s", shortcut_trigger(key))})
                    for sid, (desc, key, _cb) in shortcuts.items()
                ]
                self._request(GS_IFACE, "BindShortcuts", "(oa(sa{sv})sa{sv})",
                              lambda t: (self._gs_session, spec, "", {"handle_token": t}))
                if self._gs_sub is None:
                    self._gs_sub = self._in_loop(lambda: self._bus.signal_subscribe(
                        None, GS_IFACE, "Activated", OBJ_PATH, None, 0, self._on_shortcut))
                self.shortcuts_active = True
            except Exception:
                self.shortcuts_active = False
        return self.shortcuts_active

    def _on_shortcut(self, _conn, _sender, _path, _iface, _signal, params, *_ud) -> None:
        session, sid = params.unpack()[:2]
        if session != self._gs_session:
            return
        cb = self._gs_callbacks.get(sid)
        if cb is not None:
            try:
                cb()
            except Exception:
                pass


portal = _Portal()
