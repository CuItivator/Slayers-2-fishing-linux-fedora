PY=""
try_python() {
    if [ -x "$1" ] && "$1" -c 'import sys, venv; sys.exit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
        PY="$1"
    fi
}
if [ "$(uname)" = "Darwin" ]; then
    for v in 3.13 3.12 3.11 3.10; do
        [ -z "$PY" ] && try_python "/Library/Frameworks/Python.framework/Versions/$v/bin/python3"
    done
    for c in /opt/homebrew/bin/python3 /usr/local/bin/python3; do
        [ -z "$PY" ] && try_python "$c"
    done
fi
for n in python3.13 python3.12 python3.11 python3.10 python3; do
    if [ -z "$PY" ]; then
        c="$(command -v "$n" 2>/dev/null)"
        case "$c" in
            "") ;;
            /usr/bin/python3) [ "$(uname)" = "Darwin" ] || try_python "$c" ;;
            *) try_python "$c" ;;
        esac
    fi
done
if [ -z "$PY" ]; then
    echo ""
    if [ "$(uname)" = "Darwin" ]; then
        echo "  Python was not found on this Mac."
        echo ""
        echo "  Install Python 3.12 from"
        echo "      https://www.python.org/downloads/macos/"
    else
        echo "  Python 3.10 or newer was not found."
        echo ""
        echo "  sudo dnf install -y python3 python3-tkinter python3-gobject gstreamer1 gstreamer1-plugins-base pipewire-gstreamer tesseract tesseract-langpack-eng"
    fi
    echo "  then run this again."
    echo ""
    return 1
fi
return 0
