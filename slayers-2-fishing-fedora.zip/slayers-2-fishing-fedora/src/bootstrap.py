import hashlib
import importlib
import os
import subprocess
import sys

WINDOWS = os.name == "nt"
MAC = sys.platform == "darwin"
LINUX = not WINDOWS and not MAC
WAYLAND = LINUX and not os.environ.get("SLAYERS_FORCE_X11") and (
    os.environ.get("XDG_SESSION_TYPE", "").lower() == "wayland"
    or bool(os.environ.get("WAYLAND_DISPLAY")))
APP_ID = "io.github.vtt.Slayers2Fishing"
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
VENV = os.path.join(ROOT, ".venv")
VENV_PY = (os.path.join(VENV, "Scripts", "python.exe") if WINDOWS
           else os.path.join(VENV, "bin", "python3"))
STAMP = os.path.join(VENV, ".requirements-stamp")
LOG = os.path.join(ROOT, "setup-log.txt")
REQUIREMENTS = os.path.join(HERE, "requirements.txt")
if WINDOWS:
    LAUNCH, SETUP = "Launch.bat", "Setup.bat"
elif MAC:
    LAUNCH, SETUP = "Launch.command", "Setup.command"
else:
    LAUNCH, SETUP = "Launch.sh", "Setup.sh"

if WINDOWS:
    MUST_IMPORT = ["cv2", "numpy", "mss", "keyboard"]
elif MAC:
    MUST_IMPORT = ["cv2", "numpy", "mss", "pynput", "Quartz", "AppKit"]
else:
    MUST_IMPORT = ["cv2", "numpy", "mss", "pynput", "Xlib"]
    if WAYLAND:
        MUST_IMPORT.append("gi")

GST_PROBE = (
    "import gi; gi.require_version('Gst', '1.0'); from gi.repository import Gst; "
    "Gst.init(None); import sys; "
    "sys.exit(0 if all(Gst.ElementFactory.find(e) for e in "
    "('pipewiresrc', 'videoconvert', 'appsink')) else 1)"
)


def say(msg):
    print(" " + msg, flush=True)


def requirements_hash():
    with open(REQUIREMENTS, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def run(args, **kw):
    return subprocess.call(args, cwd=ROOT, **kw)


def run_logged(args):
    with open(LOG, "a", encoding="utf-8", errors="replace") as log:
        log.write("\n$ " + " ".join(args) + "\n")
        log.flush()
        proc = subprocess.Popen(args, cwd=ROOT, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
        for raw in proc.stdout:
            line = raw.decode("utf-8", "replace")
            sys.stdout.write(line)
            sys.stdout.flush()
            log.write(line)
        return proc.wait()


def python_info():
    v = sys.version_info
    bits = 64 if sys.maxsize > 2 ** 32 else 32
    return "Python %d.%d.%d (%d-bit) at %s" % (v.major, v.minor, v.micro, bits,
                                             sys.executable)


def tk_ok():
    try:
        importlib.import_module("tkinter")
        return True
    except Exception:
        return False


def explain_failure():
    say("")
    say("Install failed. The full output is in setup-log.txt next to %s." % LAUNCH)
    say(python_info())
    say("")
    low = ROOT.lower()
    if WINDOWS and "onedrive" in low:
        say("* This folder is inside OneDrive. OneDrive locks files while it syncs")
        say("  them, which breaks the install. Move the folder somewhere OneDrive")
        say("  does not watch (for example C:\\Games\\fishing) and run it again.")
    if sys.version_info >= (3, 14):
        say("* This Python is very new. Some of the packages may not have builds")
        say("  for it yet. Installing Python 3.12 from python.org alongside it")
        say("  is the sure fix; %s picks the newest one it can use." % LAUNCH)
    if WINDOWS:
        say("* Antivirus or Windows 'Controlled folder access' can block writes to")
        say("  .venv. Look for 'Access is denied' or 'WinError 5' in the log.")
    if not WINDOWS and not MAC:
        say("* On Linux the packages need a C compiler only when no wheel exists;")
        say("  a python.org / distro Python 3.10-3.13 on x86_64 always has wheels.")
    say("* If the log ends in a download or SSL error, that one really is the")
    say("  connection, a proxy, or a firewall.")
    say("")
    say("Run %s to try again; send setup-log.txt if it still fails." % SETUP)


def venv_has_system_packages():
    try:
        with open(os.path.join(VENV, "pyvenv.cfg"), encoding="utf-8") as f:
            return "include-system-site-packages = true" in f.read().lower()
    except OSError:
        return False


def ensure_venv():
    if os.path.exists(VENV_PY) and (not LINUX or venv_has_system_packages()):
        return True
    say("Building a private Python environment in .venv (first time only, ~20s)...")
    args = [sys.executable, "-m", "venv", "--clear", VENV]
    if LINUX:
        args.insert(3, "--system-site-packages")
    code = run_logged(args)
    if code != 0 or not os.path.exists(VENV_PY):
        say("Could not create .venv. See setup-log.txt next to %s." % LAUNCH)
        if WINDOWS:
            say("On some Python installs the 'venv' part is a tick box in the")
            say("installer under Optional Features; run the installer again and tick it.")
        else:
            say("run Setup.sh, it installs what's missing")
        return False
    return True


def wayland_ok():
    if not WAYLAND:
        return True
    if run([VENV_PY, "-c", GST_PROBE], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0:
        return True
    say("some screen sharing stuff is missing. just run Setup.sh again,")
    say("it installs it for you")
    return False


def install_desktop_entry():
    if not LINUX:
        return
    apps = os.path.join(os.path.expanduser("~"), ".local", "share", "applications")
    path = os.path.join(apps, APP_ID + ".desktop")
    body = (
        "[Desktop Entry]\n"
        "Type=Application\n"
        "Name=Slayers 2 Fishing\n"
        "Exec=\"%s\"\n"
        "Path=%s\n"
        "Icon=%s\n"
        "Terminal=true\n"
        "Categories=Game;\n"
    ) % (os.path.join(ROOT, LAUNCH), ROOT, os.path.join(HERE, "app.png"))
    try:
        try:
            with open(path, encoding="utf-8") as f:
                if f.read() == body:
                    return
        except OSError:
            pass
        os.makedirs(apps, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(body)
        os.chmod(path, 0o755)
    except OSError:
        pass


def packages_ok():
    if not os.path.exists(STAMP):
        return False
    with open(STAMP) as f:
        if f.read().strip() != requirements_hash():
            return False
    probe = "import " + ", ".join(MUST_IMPORT)
    return run([VENV_PY, "-c", probe],
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0


def install_packages():
    say("Installing packages (first time only, a minute or two)...")
    print(flush=True)
    run_logged([VENV_PY, "-m", "pip", "install", "--upgrade", "pip", "--quiet",
                "--disable-pip-version-check"])
    code = run_logged([VENV_PY, "-m", "pip", "install", "-r", REQUIREMENTS,
                       "--only-binary=:all:", "--disable-pip-version-check"])
    print(flush=True)
    if code != 0:
        explain_failure()
        return False
    probe = "import " + ", ".join(MUST_IMPORT)
    if run_logged([VENV_PY, "-c", probe]) != 0:
        say("Packages installed but something will not import. See setup-log.txt.")
        return False
    with open(STAMP, "w") as f:
        f.write(requirements_hash())
    say("Packages installed.")
    return True


def platform_notes():
    if MAC:
        say("macOS: the first run asks for Accessibility, Input Monitoring and")
        say("Screen Recording for Terminal (System Settings > Privacy & Security).")
        say("Allow all three, then start the macro again.")
    elif WAYLAND:
        say("first time you open it your desktop shows a popup to share your screen.")
        say("pick your screen, turn ON Allow Remote Interaction, then press Share.")
        say("it remembers it after that so you only do it once.")
        say("then a second popup asks about the hotkeys, just press Add / Allow.")
    elif not WINDOWS:
        say("Linux (X11): make sure Roblox/Sober is running before pressing F1.")


def main():
    if os.path.exists(LOG):
        os.remove(LOG)
    if not tk_ok():
        say("This Python has no tkinter (the window toolkit).")
        if WINDOWS:
            say("Run the python.org installer again and tick 'tcl/tk and IDLE'.")
        elif MAC:
            say("Install Python from python.org; it ships with tkinter.")
        else:
            say("run Setup.sh, it installs it for you")
        return 1
    if not ensure_venv():
        return 1
    if not packages_ok() and not install_packages():
        return 1
    if not wayland_ok():
        return 1
    install_desktop_entry()
    if os.path.exists(LOG):
        os.remove(LOG)
    args = sys.argv[1:]
    script = "main.py"
    if args and args[0].endswith(".py"):
        script, args = args[0], args[1:]
    if args and args[0] == "--check":
        platform_notes()
        return 0
    return run([VENV_PY, os.path.join(HERE, script)] + args)


if __name__ == "__main__":
    sys.exit(main())
