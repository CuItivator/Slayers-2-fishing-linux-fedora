#!/bin/bash
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python3 ]; then
    echo ""
    echo "  run Setup.sh first, it installs everything the macro needs"
    echo ""
    read -n 1 -s -r -p "  press any key to close"
    exit 1
fi
source src/find_python.sh || { read -n 1 -s -r -p "  press any key to close"; exit 1; }
"$PY" src/bootstrap.py main.py
