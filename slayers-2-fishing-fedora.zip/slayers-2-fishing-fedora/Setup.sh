#!/bin/bash
cd "$(dirname "$0")"

PKGS="python3 python3-tkinter python3-gobject gstreamer1 gstreamer1-plugins-base pipewire-gstreamer tesseract tesseract-langpack-eng"

echo ""
echo "  Slayers 2 Fishing Macro setup"
echo "  ============================="
echo ""

missing=""
for p in $PKGS; do
    rpm -q "$p" >/dev/null 2>&1 || missing="$missing $p"
done

if [ -n "$missing" ]; then
    echo "  gotta install a few things first:$missing"
    echo "  type your computer password when it asks (you wont see it as you type, thats normal lol)"
    echo ""
    if ! sudo dnf install -y $missing; then
        echo ""
        echo "  install didnt work. check your internet and run Setup.sh again"
        echo ""
        read -n 1 -s -r -p "  press any key to close"
        exit 1
    fi
    echo ""
else
    echo "  system stuff is already installed, nice"
    echo ""
fi

source src/find_python.sh || { read -n 1 -s -r -p "  press any key to close"; exit 1; }
"$PY" src/bootstrap.py main.py --check
rc=$?
echo ""
if [ $rc -ne 0 ]; then
    echo "  setup didnt finish. look at the messages above or send me setup-log.txt"
    echo ""
    read -n 1 -s -r -p "  press any key to close"
    exit 1
fi

echo "  all done. you can open it from your app menu now (search Slayers)"
echo "  or just run Launch.sh"
echo ""
read -r -p "  start the macro now? (y/n) " ans
case "$ans" in
    y|Y|yes|YES) exec "$PY" src/bootstrap.py main.py ;;
esac
